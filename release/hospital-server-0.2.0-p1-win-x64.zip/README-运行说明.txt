﻿================================================================
 智慧医院智能导诊就诊系统 · 服务端可运行包
 版本：0.2.0-p1
 打包时间：2026-10-21 22:20:57
 平台：Windows x64
================================================================

一、环境要求
  · Windows 10/11 x64（或 Windows Server 2019+）
  · 无需安装 .NET / VC++ 运行库 —— 运行时 DLL 已在包内（4 个，见文末清单）
  · 数据库：MariaDB 11.4.13 或 MySQL 8.x，监听 127.0.0.1:3317（本包默认按此口径写 DSN）
  · PowerShell 5.1 以上（只为执行下面的命令；服务端本身不依赖 PowerShell）
  · 内存 ≥ 2 GB 可用、磁盘 ≥ 200 MB

二、起数据库（两步）
  1) 解压 MariaDB 便携版，初始化数据目录（只需一次；已有数据目录就跳过）：
       & <MariaDbHome>\bin\mysql_install_db.exe --datadir=<数据目录> --password=<root口令> --port=3317
  2) 启动（--bind-address 必须给，否则会监听 0.0.0.0，同网段任何人可连）：
       & <MariaDbHome>\bin\mysqld.exe --datadir=<数据目录> --port=3317 --console --bind-address=127.0.0.1
  3) 建业务账号与库（用 root 连上后执行，口令请自行替换）：
       CREATE DATABASE IF NOT EXISTS hospital DEFAULT CHARSET utf8mb4;
       CREATE USER IF NOT EXISTS 'hospital'@'localhost' IDENTIFIED BY '<业务口令>';
       GRANT ALL PRIVILEGES ON hospital.* TO 'hospital'@'localhost';
       FLUSH PRIVILEGES;
  DSN 形状：mysql://<user>:<pass>@<host>:<port>/<db>
  本机开发库示例：mysql://hospital:hospital_dev_2026@127.0.0.1:3317/hospital

三、启动服务端
  ⚠ 本包所在路径若含中文，请先复制到纯 ASCII 路径（如 C:\hospital）再运行：
    仓颉运行时读不了含非 ASCII 的 argv（证书路径同理）。

  方式 A：双击（包内自带 start-dev.cmd，先改成你的 DSN / 端口再双击）
       start-dev.cmd
  方式 B：命令行（推荐，能看日志）
     cd <解压目录>
     .\hospital-server.exe serve "mysql://hospital:<口令>@127.0.0.1:3317/hospital" --dev-auth

  参数口径：
     --port N        监听端口，默认 8091（与客户端默认值一致，裸启动即可联调）
     --bind IP       绑定地址，默认 127.0.0.1（要局域网联调才 --bind 0.0.0.0）
     --dev-auth      开发模式：绕过全部鉴权（只认本机回环来源）。**生产禁用**，且不能与 --prod 同用
     --prod          生产模式：要求 dev_auth=false，且必须能挂到 admin-web 静态目录
     --tls-cert / --tls-key   给这两个参数就强制 HTTPS，证书读不到会直接退出，绝不静默降级

  生产模式（HTTPS）：
     .\hospital-server.exe serve "mysql://<user>:<pass>@<host>:3317/hospital" --port 8091 --prod 
         --tls-cert C:\hospital\tls\server.crt --tls-key C:\hospital\tls\server.key
     自签证书可由仓库里 server\new-tls-cert.ps1 生成；证书与私钥请放在 ASCII 路径下。

四、默认端口
  · 服务端默认 8091（--port 改），鸿蒙/安卓客户端默认也连 8091 —— 无需额外参数
  · 管理台与 API 同源同端口：http://127.0.0.1:<port>/admin/
  · 数据库默认 127.0.0.1:3317

五、/health 自检
  PowerShell：
    Invoke-WebRequest -Uri http://127.0.0.1:8091/health -UseBasicParsing | Select-Object -Expand Content
  curl：
    curl.exe -s http://127.0.0.1:8091/health
  语义：HTTP 200 = 进程活着**且**库通；HTTP 503 = 进程活着但库不通（响应体 db.ok=false）。
  响应里 db.reconnects 非 0 说明链路抖过并已自愈。

六、管理员初始化
  首次部署需要建一个管理员账号（口令由程序随机生成并打印一次，请立刻保存）：
    .\hospital-server.exe create-admin "mysql://hospital:<口令>@127.0.0.1:3317/hospital"

七、AI 出站（TLS 信任锚，必须做一次）
  仓颉 stdx 的 HTTPS 客户端走 **OpenSSL**，不读 Windows 证书存储。少了信任锚，
  AI 出站会失败并报：TLS handshake failed (client): certificate verify failed (134), unknown CA(F)
  —— 此时 curl.exe / PowerShell 访问同一个地址却都是 200，容易误判成"密钥错"。

  start-dev.cmd 会在首次运行时自动执行 export-ca-bundle.ps1 生成 ca-bundle.pem 并设置 SSL_CERT_FILE。
  手工做一遍（方式 B 走这条）：
     powershell -NoProfile -ExecutionPolicy Bypass -File .\export-ca-bundle.ps1
     set "SSL_CERT_FILE=%CD%\ca-bundle.pem"
     .\hospital-server.exe serve "<DSN>" --dev-auth
  验证：管理台「模型管理」里对默认对话模型点「测试」，应返回 ok=true / http_status=200。
  ⚠ ca-bundle.pem 由**本机**证书存储导出（含企业内网根），不要跨机器拷贝；
    换网络/换代理后要重新导一次。

八、升级到已存在的库
  serve 启动时会自动建表（CREATE TABLE IF NOT EXISTS）并跑幂等迁移；已有数据的库可直接换新 exe，
  重复启动不会重复改结构，也不会清数据。

九、故障排查
  1) 编译输出被占用（打包/重新编译时）：还有 hospital-server.exe 在跑
       Get-Process hospital-server | Stop-Process -Force
  2) 端口 3317 已被占用：Get-NetTCPConnection -State Listen | Where-Object LocalPort -eq 3317
       先停掉占用者，或改 --port / 改 DSN 端口
  3) CryptoException: Can not load openssl library or function SHA256_Init
       运行时 DLL 没跟 exe 放一起：确认本目录有 libcrypto-3-x64.dll / libssl-3-x64.dll
  4) Unexpected token（跑 .ps1 时）：脚本不是 UTF-8 with BOM
       用 [System.IO.File]::WriteAllText($p, $text, (New-Object System.Text.UTF8Encoding($true))) 重存
  5) 客户端 401/403：没开 --dev-auth 却带了 X-Role/X-User-Id 头（这些头只在 --dev-auth 下认），
     或令牌过期；--dev-auth 只认 127.0.0.1 / ::1 来源，绑 0.0.0.0 后远程请求一律 401
  6) /admin/ 404：启动时没找到 admin-web 目录（本包已随包提供，请在解压目录里启动）
  7) 服务端日志有 [HEALTH] 库探活失败：先查数据库是否在跑、DSN 口令是否正确

十、包内文件清单
    admin-web/css/style.css
    admin-web/favicon.svg
    admin-web/index.html
    admin-web/js/api.js
    admin-web/js/app.js
    admin-web/js/pages.js
    admin-web/js/ui.js
    export-ca-bundle.ps1
    hospital-server.exe
    libboundscheck.dll
    libcangjie-runtime.dll
    libcrypto-3-x64.dll
    libssl-3-x64.dll
    LICENSE.txt
    licenses/cangjie-runtime-LICENSE.txt
    licenses/cangjie-runtime-NOTICE.txt
    licenses/mariadb-driver-LICENSE.txt
    licenses/openssl-LICENSE.txt
    licenses/openssl-NOTICE.txt
    licenses/qingzhou-LICENSE.txt
    NOTICE.txt
    SOURCE-MANIFEST.sha256
    start-dev.cmd
    THIRD-PARTY.md
    README-运行说明.txt  （本文件）

================================================================