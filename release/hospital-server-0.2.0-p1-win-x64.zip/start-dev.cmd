@echo off
setlocal
rem ============================================================
rem  Smart Hospital - server launcher (dev mode)
rem  Edit DSN / PORT below, then double-click this file.
rem  NOTE: keep this folder on an ASCII-only path (e.g. C:\hospital).
rem ============================================================
set "DSN=mysql://hospital:hospital_dev_2026@127.0.0.1:3317/hospital"
set "PORT=8091"
rem --- TLS trust for outbound AI calls ---
rem  Cangjie stdx uses OpenSSL and ignores the Windows cert store.
rem  Without a trust anchor HTTPS fails: certificate verify failed (134).
rem  The PEM is generated on THIS machine on first run (never shipped).
set "CA=%~dp0ca-bundle.pem"
if not exist "%CA%" if exist "%~dp0export-ca-bundle.ps1" powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0export-ca-bundle.ps1" -Out "%CA%"
if exist "%CA%" set "SSL_CERT_FILE=%CA%"
echo Starting hospital-server on port %PORT% ...
echo Health check: http://127.0.0.1:%PORT%/health
"%~dp0hospital-server.exe" serve "%DSN%" --port %PORT% --dev-auth
echo.
echo [server exited with code %ERRORLEVEL%]
pause
